Light Remote preview files (October 10, 2026)
Open maintenance-demo.html and client-announcements-demo.html in a browser.
No production changes. Simulated publishing never sends live notifications.
Google Sans may load from the official Light Remote website; no font file is bundled.
Source: feature/free-benefit-pro-team-20261010
