Open maintenance-preview.html in a browser. Local file mode displays a 90-minute illustrative countdown. No public routing changes or client notifications. Source: Pro Team branch.
